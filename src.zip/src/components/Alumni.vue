<template>
    <div id = 'alumni'>
        <v-container>
            <v-container>
                <v-layout column>
                    <h1>Strath Uni Alumni</h1>
                </v-layout>
            </v-container>
        </v-container>
    </div>
</template>