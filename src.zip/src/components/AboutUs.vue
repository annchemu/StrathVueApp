<template>
    <div id = 'aboutus'>
        <v-container>
            <v-container>
                <v-layout column>
                    <h1>About Us</h1>
                </v-layout>
            </v-container>
        </v-container>
    </div>
</template>