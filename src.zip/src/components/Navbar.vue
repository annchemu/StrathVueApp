

<template>
    <v-app-bar color="blue" >
        <div>
            <v-btn to="/" color="white" dark >Home </v-btn>
            
        </div>
        <div>
            <v-btn to="/events" color="white" dark >Events </v-btn>
            
        </div>
        <div>
            <v-btn to="/courses" color="white" dark >Courses </v-btn>
            
        </div>
        <div>
            <v-btn to="/contactus" color="white" dark >Contact Us </v-btn>
            
        </div>
        <div>
            <v-btn to="/aboutus" color="white" dark >About Us </v-btn>
            
        </div>
        <div>
            <v-btn to="/library" color="white" dark >Library </v-btn>
            
        </div>
        <div>
            <v-btn to="/partnerships" color="white" dark >Partnerships </v-btn>
            
        </div>
        <div>
            <v-btn to="/alumni" color="white" dark >Alumni </v-btn>
            
        </div>
    </v-app-bar>
</template>
