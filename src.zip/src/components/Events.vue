<template>
    <div id = 'events'>
        <v-container>
            <v-container>
                <v-layout column>
                    <h1>School Events</h1>
                </v-layout>
            </v-container>
        </v-container>
    </div>
</template>