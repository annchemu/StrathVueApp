<template>
    <div id = 'course'>
        <v-container>
            <v-container>
                <v-layout column>
                    <h1>Course offered in Strath Uni</h1>
                </v-layout>
            </v-container>
        </v-container>
    </div>
</template>