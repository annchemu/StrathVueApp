<template>
    <div id = 'library'>
        <v-container>
            <v-container>
                <v-layout column>
                    <h1>Strath Uni Library</h1>
                </v-layout>
            </v-container>
        </v-container>
    </div>
</template>